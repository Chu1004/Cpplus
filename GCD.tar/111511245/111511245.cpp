#include <iostream>
#include <vector>

using namespace std;



bool compare(vector<int> a,vector<int> b) {
    if (a.size() != b.size()) return a.size() > b.size();
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i] != b[i]) return a[i] > b[i];
    }
    return true;
}

vector<int> subtract(vector<int> a, vector<int> b) {
    vector<int> result = a;
    int borrow = 0;

    for (size_t i = 0; i < b.size(); ++i) {
        int idx = result.size() - 1 - i;
        result[idx] -= (b[b.size() - 1 - i] + borrow);
        if (result[idx] < 0) {
            result[idx] += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
    }

    for (size_t i = b.size(); i < result.size() && borrow; ++i) {
        int idx = result.size() - 1 - i;
        result[idx] -= borrow;
        if (result[idx] < 0) {
            result[idx] += 10;
        } else {
            break;
        }
    }

    while (result.size() > 1 && result[0] == 0) {
        result.erase(result.begin());
    }

    return result;
}

vector<int> mod(vector<int> a, vector<int> b) {
    vector<int> remainder;

    for (size_t i = 0; i < a.size(); i++) {
        remainder.push_back(a[i]);

        while (remainder.size() > 1 && remainder[0] == 0) {
            remainder.erase(remainder.begin());
        }

        while (compare(remainder, b)) {
            remainder = subtract(remainder, b);
        }
    }

    return remainder;
}


vector<int> gcd(vector<int> a, vector<int> b) {
    while (!(b.size() == 1 && b[0] == 0)) {
        a = mod(a, b);
        swap(a, b);
    }
    return a;
}


void printVector(vector<int> num) {
    for (int i =0;i<num.size();i++) {
        cout << num[i];
    }
    cout << endl;
}

int main() {
    string num1, num2;
    cin >> num1 >> num2;

    vector<int> a;
    vector<int> b;
    for (int i=0;i<num1.size();i++) {
        a.push_back(num1[i] - '0');
    }
    for (int i=0;i<num2.size();i++) {
        b.push_back(num2[i] - '0');
    }

    vector<int> result = gcd(a, b);
    printVector(result);

    return 0;
}
